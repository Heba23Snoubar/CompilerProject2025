package AST;

import java.util.List;

public class IfStatement extends AstNode {
    private final List<AstNode> body; // تخزين الجسم

    public IfStatement(AstNode condition, List<AstNode> body, int line) {
        super("If", line);
        this.body = body; // حفظ القائمة

        addChild(condition);
        for (AstNode stmt : body) {
            addChild(stmt);
        }
    }

    // دالة الوصول للجسم
    public List<AstNode> getIfBody() {
        return body;
    }
}
