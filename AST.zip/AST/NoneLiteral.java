//package AST;
//
//public class NoneLiteral extends AstNode {
//
//    public NoneLiteral(int line) {
//        super("NoneLiteral", line);
//    }
//}
package AST;

public class NoneLiteral extends AstNode {

    public NoneLiteral(int line) {
        super("None", line);
    }
}
